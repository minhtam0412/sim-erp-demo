import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formcheckcomponent',
  templateUrl: './formcheckcomponent.component.html',
  styleUrls: ['./formcheckcomponent.component.css']
})
export class FormcheckcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
