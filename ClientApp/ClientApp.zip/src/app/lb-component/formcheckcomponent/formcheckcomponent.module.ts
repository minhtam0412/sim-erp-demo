import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormcheckcomponentComponent } from 'src/app/lb-component/formcheckcomponent/formcheckcomponent.component';



@NgModule({
  declarations: [
    FormcheckcomponentComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    FormcheckcomponentComponent
  ]
})
export class FormcheckcomponentModule { }
