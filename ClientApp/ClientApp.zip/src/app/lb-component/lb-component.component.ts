import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lb-component',
  templateUrl: './lb-component.component.html',
  styleUrls: ['./lb-component.component.css']
})
export class LbComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
