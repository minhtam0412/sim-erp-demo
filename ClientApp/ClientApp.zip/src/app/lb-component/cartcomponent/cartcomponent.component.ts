import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cartcomponent',
  templateUrl: './cartcomponent.component.html',
  styleUrls: ['./cartcomponent.component.css']
})
export class CartcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
