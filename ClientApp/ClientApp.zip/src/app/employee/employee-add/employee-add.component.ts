import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { Employee } from 'src/app/models/empployee';
import { EmployeeService } from 'src/app/services/employee/employee.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  @Input() clearData: boolean = false;
  @Output() nameEvent = new EventEmitter<string>();
  objTmpEmp: Employee;
  @Input() objemp: Employee = new Employee();
  @ViewChild('closeBtn', null) cb: ElementRef;
  constructor(private dataservice: EmployeeService, private route: Router, public dialogRef: MatDialogRef<EmployeeAddComponent>) { }

  ngOnInit() {
    this.ResetValues();
  }

  ResetValues() {
    this.objemp = new Employee();
    this.objemp.gender = 0;
  }

  Register(regForm: NgForm) {
    this.objTmpEmp = new Employee();
    this.objTmpEmp.email = regForm.value.email;
    this.objTmpEmp.firstname = regForm.value.firstname;
    this.objTmpEmp.lastname = regForm.value.lastname;
    this.objTmpEmp.gender = regForm.value.gender;
    this.dataservice.addEmployee(this.objTmpEmp).subscribe(res => {
      alert('Thêm nhân viên thành công');
      this.TakeHome();
    });
  }

  TakeHome() {
    this.cb.nativeElement.click();
    this.route.navigateByUrl('/employee');
  }

  closeDialog() {
    this.dialogRef.close();
  }
}
