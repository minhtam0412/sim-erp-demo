import { Component, OnInit, ViewChild, AfterViewInit, ViewChildren } from '@angular/core';
import { Employee } from 'src/app/models/empployee';
import { EmployeeService } from 'src/app/services/employee/employee.service';
import { Router } from '@angular/router';
import { EmployeeAddComponent } from '../employee-add/employee-add.component';
import { EmployeeUpdateComponent } from '../employee-update/employee-update.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit, AfterViewInit {
  @ViewChild('empadd', { static: false }) addComponent: EmployeeAddComponent;
  // @ViewChild(EmployeeUpdateComponent,{static: false}) editComponent: EmployeeUpdateComponent;
  @ViewChild(EmployeeUpdateComponent, { static: false })
  editComponent: EmployeeUpdateComponent;
  rowSelected: Employee;
  ngAfterViewInit(): void {
    console.log(this.editComponent);
  }
  employeelist: Employee[];
  dataAvailable: Boolean = false;
  empTmp: Employee;

  constructor(private dataservice: EmployeeService, private route: Router, public dialog: MatDialog) {
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.dataservice.getEmployee().subscribe((template) => {
      this.employeelist = template;
      console.log(this.employeelist);
      if (this.employeelist.length > 0) {
        this.dataAvailable = true;
      } else {
        this.dataAvailable = false;
      }
    }, err => {
      console.log(err);
    });
  }

  deleteConfirmation(id: string) {
    if (confirm('Bạn có chắc muốn xoá dữ liệu đang chọn?')) {
      this.empTmp = new Employee();
      this.empTmp.id = id;
      this.dataservice.delEmployee(this.empTmp).subscribe((res) => {
        alert('Xoá thành công!');
        this.loadData();
      }, err => {
        console.log(err);
      });
    }
  }

  loadAddNew() {
    this.addComponent.objemp = new Employee();
    this.addComponent.objemp.email = '';
    this.addComponent.objemp.firstname = '';
    this.addComponent.objemp.lastname = '';
    this.addComponent.objemp.id = '';
    this.addComponent.objemp.gender = 0;
  }
  loadNewForm(id: string, email: string, firstName: string, lastName: string, gender: number) {
    this.rowSelected = new Employee();
    this.rowSelected.id = id;
    this.rowSelected.firstname = firstName;
    this.rowSelected.lastname = lastName;
    this.rowSelected.gender = gender;
    this.rowSelected.email = email;
    this.openUpdateDialog();
  }
  refreshData() {
    this.loadData();
  }

  openAddDialog(): void {

    const dialogRef = this.dialog.open(EmployeeAddComponent, {
      width: '600px'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // console.log(result.rsl);
      // this.refreshData();
    });
  }

  openUpdateDialog(): void {
    const dialogRef = this.dialog.open(EmployeeUpdateComponent, {
      width: '600px',
      data: this.rowSelected
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // console.log(result.rsl);
      this.refreshData();
    });
  }


}
