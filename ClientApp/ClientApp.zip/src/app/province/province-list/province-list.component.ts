import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-province-list',
  templateUrl: './province-list.component.html',
  styleUrls: ['./province-list.component.css']
})
export class ProvinceListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
