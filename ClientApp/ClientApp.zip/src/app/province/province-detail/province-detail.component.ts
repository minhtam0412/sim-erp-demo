import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-province-detail',
  templateUrl: './province-detail.component.html',
  styleUrls: ['./province-detail.component.css']
})
export class ProvinceDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
